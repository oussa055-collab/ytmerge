package com.example.ytmerge

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** يسجّل الـ crash وأسباب إغلاق الابليكاسيون وسجل الرفع (باش نعرفو شنو صاير بالضبط) */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
    }
}

object CrashLog {
    private fun crashFile(ctx: Context) = File(ctx.filesDir, "crash.txt")
    private fun logFile(ctx: Context) = File(ctx.filesDir, "upload.log")

    private fun fmt(ms: Long): String =
        SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date(ms))

    fun install(ctx: Context) {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                crashFile(ctx).writeText(
                    "${fmt(System.currentTimeMillis())} thread=${t.name}\n" +
                        Log.getStackTraceString(e).take(4000)
                )
            }
            prev?.uncaughtException(t, e)
        }
    }

    @Synchronized
    fun log(ctx: Context, line: String) {
        runCatching {
            val f = logFile(ctx)
            f.appendText("${fmt(System.currentTimeMillis())} $line\n")
            if (f.length() > 80_000) {
                f.writeText(f.readLines().takeLast(300).joinToString("\n") + "\n")
            }
        }
    }

    fun readLog(ctx: Context, maxLines: Int = 50): String =
        runCatching { logFile(ctx).readLines().takeLast(maxLines).joinToString("\n") }.getOrDefault("")

    fun readCrash(ctx: Context): String =
        runCatching { crashFile(ctx).readText() }.getOrDefault("")

    private fun reasonName(r: Int): String = when (r) {
        1 -> "EXIT_SELF"
        2 -> "SIGNALED (killed)"
        3 -> "LOW_MEMORY"
        4 -> "CRASH"
        5 -> "CRASH_NATIVE"
        6 -> "ANR"
        7 -> "INITIALIZATION_FAILURE"
        8 -> "PERMISSION_CHANGE"
        9 -> "EXCESSIVE_RESOURCE_USAGE"
        10 -> "USER_REQUESTED"
        11 -> "USER_STOPPED"
        12 -> "DEPENDENCY_DIED"
        13 -> "OTHER"
        14 -> "FREEZER"
        else -> "UNKNOWN($r)"
    }

    /** آخر إغلاقات للابليكاسيون من النظام (Android 11+) */
    fun exitReasons(ctx: Context): String {
        if (Build.VERSION.SDK_INT < 30) return ""
        return runCatching {
            ctx.getSystemService(ActivityManager::class.java)
                .getHistoricalProcessExitReasons(ctx.packageName, 0, 6)
                .joinToString("\n") { i ->
                    "${fmt(i.timestamp)} ${reasonName(i.reason)} ${i.description ?: ""}"
                }
        }.getOrDefault("")
    }
}
