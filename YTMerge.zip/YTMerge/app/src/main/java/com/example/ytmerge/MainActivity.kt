package com.example.ytmerge

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.auth.api.identity.Identity

/** زوج: فيديو + السوتيتراج متاعو */
data class VideoItem(
    val videoUri: Uri,
    val videoName: String,
    val subUri: Uri,
    val subName: String
)

class MergeViewModel : ViewModel() {
    val items = mutableStateListOf<VideoItem>()

    // الفيديو اللي تختار وننتظرو السوتيتراج متاعو
    var pendingVideo by mutableStateOf<Pair<Uri, String>?>(null)

    fun addPair(videoUri: Uri, videoName: String, subUri: Uri, subName: String) {
        items.add(VideoItem(videoUri, videoName, subUri, subName))
        pendingVideo = null
    }

    fun move(index: Int, delta: Int) {
        val target = index + delta
        if (target !in items.indices) return
        val item = items.removeAt(index)
        items.add(target, item)
    }

    fun remove(index: Int) {
        items.removeAt(index)
    }
}

fun Context.displayName(uri: Uri): String =
    contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    } ?: uri.lastPathSegment ?: "؟"

fun Context.keepAccess(uri: Uri) {
    // باش الابليكاسيون تنجم تقرا الملف بعد، حتى كي تسكر وتفتح
    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Screen(vm: MergeViewModel = viewModel()) {
    val ctx = LocalContext.current
    var title by rememberSaveable { mutableStateOf("") }
    var wifiOnly by remember { mutableStateOf(UploadSettings.wifiOnly(ctx)) }
    var message by remember { mutableStateOf<String?>(null) }

    // صلاحية الإشعارات (Android 13+) باش تشوف تقدم الرفع
    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    fun startUpload() {
        enqueueUpload(ctx, title.ifBlank { "فيديو" }, vm.items.toList())
        message = "بدا الرفع في الخلفية. شوف الإشعار."
    }

    // موافقة Google (تتطلب مرة وحدة)
    val authLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) startUpload()
        else message = "لازم توافق على صلاحيات يوتيوب."
    }

    fun connectAndUpload() {
        Identity.getAuthorizationClient(ctx).authorize(YouTubeAuth.request())
            .addOnSuccessListener { r ->
                if (r.hasResolution()) {
                    authLauncher.launch(IntentSenderRequest.Builder(r.pendingIntent!!.intentSender).build())
                } else startUpload()
            }
            .addOnFailureListener { message = "فشل الاتصال بحساب Google: ${it.message}" }
    }

    // 2) اختيار السوتيتراج (يتحل بعد الفيديو مباشرة)
    val subPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        val video = vm.pendingVideo
        if (uri != null && video != null) {
            ctx.keepAccess(uri)
            vm.addPair(video.first, video.second, uri, ctx.displayName(uri))
        } else {
            // لغى السوتيتراج ← نلغيو الفيديو باش ما تصيرش لخبطة
            vm.pendingVideo = null
        }
    }

    // 1) اختيار الفيديو
    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            ctx.keepAccess(uri)
            vm.pendingVideo = uri to ctx.displayName(uri)
            subPicker.launch(arrayOf("application/x-subrip", "text/*", "application/octet-stream"))
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("دمج ورفع الفيديوهات") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { videoPicker.launch(arrayOf("video/*")) },
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("إضافة فيديو") }
            )
        },
        bottomBar = {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان الفيديو في يوتيوب") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("الرفع بالواي فاي فقط", Modifier.weight(1f))
                    Switch(
                        checked = wifiOnly,
                        onCheckedChange = {
                            wifiOnly = it
                            UploadSettings.setWifiOnly(ctx, it)
                        }
                    )
                }
                message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                Button(
                    onClick = { connectAndUpload() },
                    enabled = vm.items.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("ارفع لليوتيوب") }
            }
        }
    ) { padding ->
        if (vm.items.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("زيد فيديو، وبعدها نطلب منك السوتيتراج متاعو")
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(vm.items) { index, item ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${index + 1}", style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.videoName, maxLines = 1)
                                Text(
                                    "سوتيتراج: ${item.subName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1
                                )
                            }
                            IconButton(onClick = { vm.move(index, -1) }) {
                                Icon(Icons.Default.KeyboardArrowUp, "فوق")
                            }
                            IconButton(onClick = { vm.move(index, 1) }) {
                                Icon(Icons.Default.KeyboardArrowDown, "تحت")
                            }
                            IconButton(onClick = { vm.remove(index) }) {
                                Icon(Icons.Default.Delete, "حذف")
                            }
                        }
                    }
                }
            }
        }
    }
}
