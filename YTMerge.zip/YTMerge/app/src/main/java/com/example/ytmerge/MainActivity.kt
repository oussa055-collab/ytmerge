package com.example.ytmerge

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.core.app.NotificationManagerCompat
import androidx.work.WorkManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.paint
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.delay
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.auth.api.identity.Identity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** زوج: فيديو + السوتيتراج متاعو */
data class VideoItem(
    val videoUri: Uri,
    val videoName: String,
    val subUri: Uri,
    val subName: String
)

/** حفظ القائمة في تخزين الابليكاسيون (تبقى حتى بعد التحديث أو الإغلاق) */
object ItemsStore {
    private fun file(ctx: Context) = File(ctx.filesDir, "list.json")

    fun save(ctx: Context, title: String, items: List<VideoItem>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(
                JSONObject()
                    .put("v", it.videoUri.toString()).put("vn", it.videoName)
                    .put("s", it.subUri.toString()).put("sn", it.subName)
            )
        }
        runCatching {
            file(ctx).writeText(JSONObject().put("title", title).put("items", arr).toString())
        }
    }

    /** يرجع العنوان والقائمة، ويتخطّى الملفات اللي ما عادش تتقرا (تفسخت مثلاً) */
    fun load(ctx: Context): Pair<String, List<VideoItem>>? = runCatching {
        val f = file(ctx)
        if (!f.exists()) return null
        val o = JSONObject(f.readText())
        val arr = o.getJSONArray("items")
        fun readable(u: Uri) = runCatching { ctx.contentResolver.openInputStream(u)!!.close(); true }.getOrDefault(false)
        val items = (0 until arr.length()).mapNotNull {
            val j = arr.getJSONObject(it)
            val v = Uri.parse(j.getString("v"))
            val sub = Uri.parse(j.getString("s"))
            if (readable(v) && readable(sub)) VideoItem(v, j.getString("vn"), sub, j.getString("sn")) else null
        }
        o.optString("title", "") to items
    }.getOrNull()
}

class MergeViewModel : ViewModel() {
    val items = mutableStateListOf<VideoItem>()
    var title by mutableStateOf("")

    // الفيديو اللي تختار وننتظرو السوتيتراج متاعو
    var pendingVideo by mutableStateOf<Pair<Uri, String>?>(null)

    private var appCtx: Context? = null

    /** مرة وحدة: يرجّع القائمة المحفوظة */
    fun attach(ctx: Context) {
        if (appCtx != null) return
        appCtx = ctx.applicationContext
        ItemsStore.load(ctx)?.let { (t, list) ->
            title = t
            items.addAll(list)
        }
    }

    fun persist() {
        appCtx?.let { ItemsStore.save(it, title, items.toList()) }
    }

    fun addPair(videoUri: Uri, videoName: String, subUri: Uri, subName: String) {
        items.add(VideoItem(videoUri, videoName, subUri, subName))
        pendingVideo = null
        persist()
    }

    fun move(index: Int, delta: Int) {
        val target = index + delta
        if (target !in items.indices) return
        val item = items.removeAt(index)
        items.add(target, item)
        persist()
    }

    fun remove(index: Int) {
        val item = items.removeAt(index)
        appCtx?.let { c ->
            // نحرّرو الصلاحية باش ما تتعمّرش (الحد الأقصى محدود)
            runCatching { c.contentResolver.releasePersistableUriPermission(item.videoUri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            runCatching { c.contentResolver.releasePersistableUriPermission(item.subUri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        }
        persist()
    }
}

fun Context.displayName(uri: Uri): String =
    contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    } ?: uri.lastPathSegment ?: "؟"

fun Context.keepAccess(uri: Uri) {
    // باش الابليكاسيون تنجم تقرا الملف بعد، حتى كي تسكر وتفتح
    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Screen(vm: MergeViewModel = viewModel()) {
    val ctx = LocalContext.current
    vm.attach(ctx)
    var wifiOnly by remember { mutableStateOf(UploadSettings.wifiOnly(ctx)) }
    var message by remember { mutableStateOf<String?>(null) }

    // حالة الرفع الحقيقية (تتحدّث كل ثانية)
    var status by remember { mutableStateOf(UploadStatus.get(ctx)) }
    var workState by remember { mutableStateOf<String?>(null) }
    var progress by remember { mutableStateOf(UploadProgress.read(ctx)) }
    var notifOk by remember { mutableStateOf(true) }
    var showBg by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            status = UploadStatus.get(ctx)
            progress = UploadProgress.read(ctx)
            notifOk = NotificationManagerCompat.from(ctx).areNotificationsEnabled()
            val st = withContext(Dispatchers.IO) {
                runCatching {
                    WorkManager.getInstance(ctx).getWorkInfosForUniqueWork("yt_upload").get()
                        .firstOrNull()?.state?.name
                }.getOrNull()
            }
            workState = when (st) {
                "RUNNING" -> "شغّال"
                "ENQUEUED" -> "في الانتظار (واي فاي / النظام)"
                "SUCCEEDED" -> "تم"
                "FAILED" -> "فشل"
                "CANCELLED" -> "ملغى"
                "BLOCKED" -> "في الانتظار"
                else -> null
            }
            delay(1000)
        }
    }

    // صلاحية الإشعارات (Android 13+) باش تشوف تقدم الرفع
    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    fun startUpload() {
        enqueueUpload(ctx, vm.title.ifBlank { "فيديو" }, vm.items.toList())
        message = "بدا الرفع في الخلفية. شوف الإشعار."
    }

    // موافقة Google (تتطلب مرة وحدة)
    val authLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) startUpload()
        else message = "لازم توافق على صلاحيات يوتيوب."
    }

    fun connectAndUpload() {
        Identity.getAuthorizationClient(ctx).authorize(YouTubeAuth.request())
            .addOnSuccessListener { r ->
                if (r.hasResolution()) {
                    authLauncher.launch(IntentSenderRequest.Builder(r.pendingIntent!!.intentSender).build())
                } else startUpload()
            }
            .addOnFailureListener { message = "فشل الاتصال بحساب Google: ${it.message}" }
    }

    // 2) اختيار السوتيتراج (يتحل بعد الفيديو مباشرة)
    val subPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        val video = vm.pendingVideo
        if (uri != null && video != null) {
            ctx.keepAccess(uri)
            vm.addPair(video.first, video.second, uri, ctx.displayName(uri))
        } else {
            // لغى السوتيتراج ← نلغيو الفيديو باش ما تصيرش لخبطة
            vm.pendingVideo = null
        }
    }

    // 1) اختيار الفيديو
    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            ctx.keepAccess(uri)
            vm.pendingVideo = uri to ctx.displayName(uri)
            subPicker.launch(arrayOf("application/x-subrip", "text/*", "application/octet-stream"))
        }
    }

    val barColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)

    if (showBg) {
        AlertDialog(
            onDismissRequest = { showBg = false },
            confirmButton = { TextButton(onClick = { showBg = false }) { Text("تمام") } },
            title = { Text("الرفع في الخلفية") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "تليفونات Xiaomi تقتل الابليكاسيونات في الخلفية. باش يكمل الرفع كي تخرج:\n" +
                            "• خلّي الإشعارات مفتوحة\n" +
                            "• البطارية: بلا قيود (No restrictions)\n" +
                            "• التشغيل التلقائي (Autostart): مفعّل\n" +
                            "• في قائمة التطبيقات الأخيرة: اقفل الابليكاسيون (قفل صغير)"
                    )
                    Button(onClick = { requestIgnoreBattery(ctx) }, modifier = Modifier.fillMaxWidth()) {
                        Text("1) السماح بالعمل في الخلفية")
                    }
                    Button(onClick = { openNotifSettings(ctx) }, modifier = Modifier.fillMaxWidth()) {
                        Text("2) إعدادات الإشعارات")
                    }
                    Button(onClick = { openAppSettings(ctx) }, modifier = Modifier.fillMaxWidth()) {
                        Text("3) إعدادات الابليكاسيون")
                    }
                }
            }
        )
    }

    Scaffold(
        // صورة الخلفية (wallpaper) على كامل الشاشة
        modifier = Modifier.fillMaxSize().paint(
            painterResource(R.drawable.bg_wallpaper),
            sizeToIntrinsics = false,
            contentScale = ContentScale.Crop
        ),
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("دمج ورفع الفيديوهات") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = barColor)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { videoPicker.launch(arrayOf("video/*")) },
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("إضافة فيديو") }
            )
        },
        bottomBar = {
            Column(
                Modifier.fillMaxWidth().background(barColor).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = vm.title,
                    onValueChange = { vm.title = it; vm.persist() },
                    label = { Text("عنوان الفيديو في يوتيوب") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("الرفع بالواي فاي فقط", Modifier.weight(1f))
                    Switch(
                        checked = wifiOnly,
                        onCheckedChange = {
                            wifiOnly = it
                            UploadSettings.setWifiOnly(ctx, it)
                        }
                    )
                }
                totalProgress(progress)?.let { t ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            "المجموع: ${(t * 100).toInt()}%  (${progress.sent / (1024 * 1024)} / ${progress.total / (1024 * 1024)} MB)",
                            style = MaterialTheme.typography.bodySmall
                        )
                        LinearProgressIndicator(progress = { t }, modifier = Modifier.fillMaxWidth())
                    }
                }
                workState?.let { Text("حالة المهمة: $it", style = MaterialTheme.typography.bodySmall) }
                if (!notifOk) {
                    Text(
                        "⚠ الإشعارات مقفولة: النظام ممكن يقتل الرفع كي تخرج من الابليكاسيون",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                TextButton(onClick = { showBg = true }) { Text("⚙ باش الرفع يكمل كي تخرج من الابليكاسيون") }
                if (status.isNotEmpty()) {
                    Text(status, style = MaterialTheme.typography.bodyMedium)
                } else {
                    message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                }
                Button(
                    onClick = { connectAndUpload() },
                    enabled = vm.items.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("ارفع لليوتيوب") }
            }
        }
    ) { padding ->
        if (vm.items.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)
                ) {
                    Text("زيد فيديو، وبعدها نطلب منك السوتيتراج متاعو", Modifier.padding(16.dp))
                }
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(vm.items) { index, item ->
                    Card(Modifier.fillMaxWidth()) {
                        Column {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${index + 1}", style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.videoName, maxLines = 1)
                                Text(
                                    "سوتيتراج: ${item.subName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1
                                )
                            }
                            IconButton(onClick = { vm.move(index, -1) }) {
                                Icon(Icons.Default.KeyboardArrowUp, "فوق")
                            }
                            IconButton(onClick = { vm.move(index, 1) }) {
                                Icon(Icons.Default.KeyboardArrowDown, "تحت")
                            }
                            IconButton(onClick = { vm.remove(index) }) {
                                Icon(Icons.Default.Delete, "حذف")
                            }
                        }
                        itemProgress(progress, index, vm.items.size)?.let { p ->
                            Row(
                                Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                LinearProgressIndicator(progress = { p }, modifier = Modifier.weight(1f))
                                Spacer(Modifier.width(8.dp))
                                Text("${(p * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        }
                    }
                }
            }
        }
    }
}

private fun launchSettings(ctx: Context, intent: Intent) {
    runCatching { ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

fun requestIgnoreBattery(ctx: Context) = launchSettings(
    ctx,
    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
)

fun openNotifSettings(ctx: Context) = launchSettings(
    ctx,
    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
)

fun openAppSettings(ctx: Context) = launchSettings(
    ctx,
    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
)

/** تقدّم فيديو واحد (تقدير: حجم الفيديو الأصلي داخل الـ stream المدموج) */
fun itemProgress(p: UploadProgressData, index: Int, itemCount: Int): Float? {
    if (p.total <= 0 || p.sizes.size != itemCount) return null
    val size = p.sizes[index]
    if (size <= 0) return null
    if (p.done) return 1f
    val start = p.sizes.take(index).sum()
    return ((p.sent - start).toFloat() / size).coerceIn(0f, 1f)
}

/** التقدّم الكلي (يبقى 99% حتى يكمل الرفع فعلاً) */
fun totalProgress(p: UploadProgressData): Float? {
    if (p.total <= 0) return null
    if (p.done) return 1f
    return (p.sent.toFloat() / p.total).coerceIn(0f, 0.99f)
}
