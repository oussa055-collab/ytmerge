package com.example.ytmerge

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

object SrtMerger {

    data class Cue(val startMs: Long, val endMs: Long, val text: String)

    private val TIME = Regex(
        """(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})"""
    )

    private fun toMs(h: String, m: String, s: String, ms: String): Long =
        h.toLong() * 3_600_000 + m.toLong() * 60_000 + s.toLong() * 1_000 +
            ms.padEnd(3, '0').toLong()

    private fun fmt(ms: Long): String {
        val h = ms / 3_600_000
        val m = (ms % 3_600_000) / 60_000
        val s = (ms % 60_000) / 1_000
        val r = ms % 1_000
        return "%02d:%02d:%02d,%03d".format(h, m, s, r)
    }

    /** يقرا ملف SRT ويرجع قائمة cues */
    fun parse(content: String): List<Cue> {
        val clean = content.removePrefix("\uFEFF").replace("\r\n", "\n").replace("\r", "\n")
        val cues = mutableListOf<Cue>()
        for (block in clean.split(Regex("\n{2,}"))) {
            val lines = block.trim().lines()
            val timeIdx = lines.indexOfFirst { TIME.containsMatchIn(it) }
            if (timeIdx < 0) continue
            val g = TIME.find(lines[timeIdx])!!.groupValues
            val start = toMs(g[1], g[2], g[3], g[4])
            val end = toMs(g[5], g[6], g[7], g[8])
            val text = lines.drop(timeIdx + 1).joinToString("\n").trim()
            if (text.isNotEmpty()) cues.add(Cue(start, end, text))
        }
        return cues
    }

    /**
     * يدمج الملفات: كل ملف يتزاد عليه مجموع مدد الفيديوهات اللي قبلو.
     * parts = قائمة (محتوى SRT, مدة الفيديو بالميلي ثانية) بنفس ترتيب الفيديوهات.
     */
    fun merge(parts: List<Pair<String, Long>>): String {
        val out = StringBuilder()
        var offset = 0L
        var index = 1
        for ((content, durationMs) in parts) {
            for (cue in parse(content)) {
                out.append(index++).append('\n')
                out.append(fmt(cue.startMs + offset)).append(" --> ")
                    .append(fmt(cue.endMs + offset)).append('\n')
                out.append(cue.text).append("\n\n")
            }
            offset += durationMs
        }
        return out.toString()
    }

    /** مدة الفيديو بالميلي ثانية */
    fun videoDurationMs(ctx: Context, uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
        } finally {
            r.release()
        }
    }

    /**
     * يكتشف ترميز الملف (encoding) وحدو يحوّلو لنص سليم.
     * يجرب: UTF-8 مع BOM ← UTF-16 ← UTF-8 عادي ← وإلا Windows-1256 (عربي قديم).
     */
    fun decodeSmart(bytes: ByteArray): String {
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() &&
            bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()
        ) return String(bytes, 3, bytes.size - 3, Charsets.UTF_8)

        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte())
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)

        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte())
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)

        val strictUtf8 = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        return try {
            strictUtf8.decode(ByteBuffer.wrap(bytes)).toString()
        } catch (e: CharacterCodingException) {
            String(bytes, Charset.forName("windows-1256"))
        }
    }

    /** من القائمة متاع الابليكاسيون ← نص SRT واحد جاهز للرفع (دايماً UTF-8) */
    suspend fun mergeItems(ctx: Context, items: List<VideoItem>): String =
        withContext(Dispatchers.IO) {
            val parts = items.map { item ->
                val bytes = ctx.contentResolver.openInputStream(item.subUri)!!
                    .use { it.readBytes() }
                decodeSmart(bytes) to videoDurationMs(ctx, item.videoUri)
            }
            merge(parts)
        }
}
