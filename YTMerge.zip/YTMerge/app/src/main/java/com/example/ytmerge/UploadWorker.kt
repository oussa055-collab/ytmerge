package com.example.ytmerge

import android.app.Notification
import android.app.NotificationChannel
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Intent
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.Session
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/* ============================================================
 *  1) الإعدادات: واي فاي فقط (par défaut) أو بالدوني
 * ============================================================ */
object UploadSettings {
    private fun p(ctx: Context) = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun wifiOnly(ctx: Context) = p(ctx).getBoolean("wifi_only", true)
    fun setWifiOnly(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("wifi_only", v).apply()

    fun networkAllowed(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        val needed = if (wifiOnly(ctx)) NetworkCapabilities.NET_CAPABILITY_NOT_METERED
        else NetworkCapabilities.NET_CAPABILITY_INTERNET
        return caps.hasCapability(needed)
    }
}

/** نص الحالة اللي يظهر في الابليكاسيون (باش تعرف شنو صاير) */
object UploadStatus {
    private fun p(ctx: Context) = ctx.getSharedPreferences("upload_status", Context.MODE_PRIVATE)
    fun set(ctx: Context, text: String) {
        p(ctx).edit().putString("text", text).apply()
        if (!text.startsWith("جاري الرفع")) CrashLog.log(ctx, text)
    }
    fun get(ctx: Context): String = p(ctx).getString("text", "") ?: ""
}

/** تقدّم الرفع (باش الابليكاسيون تعرض البارات) */
data class UploadProgressData(
    val sent: Long, val total: Long, val sizes: List<Long>, val done: Boolean
)

object UploadProgress {
    private fun p(ctx: Context) = ctx.getSharedPreferences("upload_progress", Context.MODE_PRIVATE)

    fun clear(ctx: Context) = p(ctx).edit().clear().apply()

    fun start(ctx: Context, sizes: List<Long>) {
        p(ctx).edit()
            .putString("sizes", sizes.joinToString(","))
            .putLong("total", sizes.sum())
            .putLong("sent", 0)
            .putBoolean("done", false)
            .apply()
    }

    fun update(ctx: Context, sent: Long) = p(ctx).edit().putLong("sent", sent).apply()
    fun done(ctx: Context) = p(ctx).edit().putBoolean("done", true).apply()

    fun read(ctx: Context): UploadProgressData {
        val pr = p(ctx)
        val sizes = (pr.getString("sizes", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }
        return UploadProgressData(pr.getLong("sent", 0), pr.getLong("total", 0), sizes, pr.getBoolean("done", false))
    }
}

fun fileSize(ctx: Context, uri: Uri): Long = runCatching {
    ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L
}.getOrDefault(0L).coerceAtLeast(0L)

/* ============================================================
 *  2) تخزين المهمة (باش الـ Worker يعاود يبدا كان تسكّر الابليكاسيون)
 * ============================================================ */
object UploadJob {
    private fun file(ctx: Context) = File(ctx.filesDir, "job.json")
    private fun state(ctx: Context) = ctx.getSharedPreferences("upload_state", Context.MODE_PRIVATE)

    fun save(ctx: Context, title: String, items: List<VideoItem>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject()
                .put("v", it.videoUri.toString()).put("vn", it.videoName)
                .put("s", it.subUri.toString()).put("sn", it.subName))
        }
        file(ctx).writeText(JSONObject().put("title", title).put("items", arr).toString())
        state(ctx).edit().clear().apply() // مهمة جديدة ← نمسحو الحالة القديمة
    }

    fun load(ctx: Context): Pair<String, List<VideoItem>> {
        val o = JSONObject(file(ctx).readText())
        val arr = o.getJSONArray("items")
        val items = (0 until arr.length()).map {
            val j = arr.getJSONObject(it)
            VideoItem(Uri.parse(j.getString("v")), j.getString("vn"), Uri.parse(j.getString("s")), j.getString("sn"))
        }
        return o.getString("title") to items
    }

    fun prefs(ctx: Context) = state(ctx)
}

fun enqueueUpload(ctx: Context, title: String, items: List<VideoItem>) {
    UploadControl.setPaused(ctx, false)
    UploadJob.save(ctx, title, items)
    UploadProgress.clear(ctx)
    UploadStatus.set(
        ctx,
        if (UploadSettings.wifiOnly(ctx)) "في الانتظار: الرفع يبدا كي تكون متصل بالواي فاي..."
        else "في الانتظار: الرفع باش يبدا..."
    )
    WorkManager.getInstance(ctx).enqueueUniqueWork("yt_upload", ExistingWorkPolicy.REPLACE, uploadRequest())
}

// واي فاي فقط نطبّقوه مباشرة داخل الـ Worker (باش يتبدل في اللحظة كي تبدل المفتاح)
private fun uploadRequest() = OneTimeWorkRequestBuilder<UploadWorker>()
    .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
    .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.SECONDS)
    .build()

/** إيقاف مؤقت / استئناف */
object UploadControl {
    private fun p(ctx: Context) = ctx.getSharedPreferences("upload_control", Context.MODE_PRIVATE)
    fun isPaused(ctx: Context) = p(ctx).getBoolean("paused", false)
    fun setPaused(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("paused", v).apply()
}

/** يوقف الرفع (والإشعار يتنحّى) ويحفظ الجلسة باش يكمل من وين وقف */
fun pauseUpload(ctx: Context) {
    UploadControl.setPaused(ctx, true)
    WorkManager.getInstance(ctx).cancelUniqueWork("yt_upload")
    UploadStatus.set(ctx, "⏸ الرفع في وضع الإيقاف المؤقت. دوس \"استئناف\" باش يكمل من وين وقف")
}

fun resumeUpload(ctx: Context) {
    UploadControl.setPaused(ctx, false)
    UploadStatus.set(ctx, "▶ استئناف الرفع...")
    WorkManager.getInstance(ctx).enqueueUniqueWork("yt_upload", ExistingWorkPolicy.REPLACE, uploadRequest())
}

/** أزرار الإشعار: إيقاف مؤقت / إلغاء */
class UploadControlReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            "ytmerge.PAUSE" -> pauseUpload(ctx)
            "ytmerge.CANCEL" -> cancelUpload(ctx)
        }
    }
}

/* ============================================================
 *  3) تسجيل الدخول (OAuth) والحصول على token
 *  لازم قبلها تعمل authorize مرة وحدة من الشاشة (UI) باش المستخدم يوافق.
 * ============================================================ */
object YouTubeAuth {
    private val SCOPES = listOf(
        Scope("https://www.googleapis.com/auth/youtube.upload"),
        Scope("https://www.googleapis.com/auth/youtube.force-ssl") // للـ captions
    )

    fun request(): AuthorizationRequest =
        AuthorizationRequest.builder().setRequestedScopes(SCOPES).build()

    /** يرجع null كان لازم المستخدم يوافق من الشاشة */
    suspend fun accessToken(ctx: Context): String? {
        val res = Identity.getAuthorizationClient(ctx).authorize(request()).await()
        return if (res.hasResolution()) null else res.accessToken
    }
}

/* ============================================================
 *  4) الدمج: FFmpeg يلصق الفيديوهات (بلا re-encoding) ويخرّجها في pipe
 *  صيغة fragmented MP4 باش تتقرا كـ stream من غير ملف كامل.
 * ============================================================ */
/** مصدر بيانات الفيديو المدموج (stream) */
interface VideoStream : AutoCloseable {
    val input: InputStream
    fun logs(): String
}

/**
 * FFmpeg ما يقدرش يقرا فيديوهات التليفون مباشرة (saf يتعطّل، و/proc ممنوع).
 * الحل: ننسخو فيديو واحد كل مرة للكاش (فقط وقت ما يلزم)، وFFmpeg يقراه بمسار عادي.
 * وننحّيو النسخ القديمة بعد ما يكمل منها، باش ما ناكلوش المساحة.
 */
class JitSegments(
    private val ctx: Context,
    private val items: List<VideoItem>,
    private val dir: File
) {
    private val mb = 1024L * 1024L
    private val cumEnd = LongArray(items.size)
    private var copiedUpTo = -1
    private var lastPrepared = -1L

    init {
        dir.deleteRecursively()
        dir.mkdirs()
        var c = 0L
        items.forEachIndexed { i, it ->
            c += fileSize(ctx, it.videoUri).coerceAtLeast(1L)
            cumEnd[i] = c
        }
    }

    fun path(i: Int) = File(dir, "seg_$i.mp4")

    private fun indexAt(inputPos: Long): Int {
        for (i in cumEnd.indices) if (inputPos < cumEnd[i]) return i
        return cumEnd.size - 1
    }

    private fun copy(i: Int) {
        val dst = path(i)
        if (dst.exists()) return
        val need = (if (i == 0) cumEnd[0] else cumEnd[i] - cumEnd[i - 1]) + 300 * mb
        if (dir.usableSpace < need) {
            throw IllegalStateException(
                "مساحة التليفون ما تكفيش: نحتاج حوالي ${need / mb} MB فاضية مؤقتاً (نسخة فيديو واحد كل مرة)"
            )
        }
        UploadStatus.set(ctx, "ننسخ الفيديو ${i + 1} من ${items.size} مؤقتاً للمعالجة...")
        val tmp = File(dir, "seg_$i.tmp")
        val ins = ctx.contentResolver.openInputStream(items[i].videoUri)
            ?: throw IllegalStateException("ما نجمتش نقرا الفيديو رقم ${i + 1} (${items[i].videoName})")
        ins.use { input -> tmp.outputStream().use { out -> input.copyTo(out, 1 shl 20) } }
        if (!tmp.renameTo(dst)) throw IllegalStateException("ما نجمتش ننهي نسخ الفيديو رقم ${i + 1}")
        CrashLog.log(ctx, "نسخنا الفيديو ${i + 1} للكاش ✓")
    }

    /** نتأكدو إن الفيديوهات اللي باش يحتاجها FFmpeg موجودة، وننحّيو اللي فات */
    fun prepare(outPos: Long) {
        if (lastPrepared >= 0 && outPos - lastPrepared < 4 * mb) return
        lastPrepared = outPos
        // FFmpeg يقدم شوية على اللي قريناه (الخرج أصغر شوية من الدخل + buffer)
        val hi = indexAt((outPos * 1.06).toLong() + 48 * mb)
        while (copiedUpTo < hi) {
            copiedUpTo++
            copy(copiedUpTo)
        }
        val lowPos = (outPos * 0.94).toLong() - 48 * mb
        for (j in 0 until copiedUpTo) if (cumEnd[j] < lowPos) path(j).delete()
    }

    fun cleanup() {
        runCatching { dir.deleteRecursively() }
    }
}

/** stream يستنّى النسخ الجاهزة قبل ما يقرا (باش FFmpeg ما يلقاش ملف ناقص) */
private class GatedInputStream(
    private val base: InputStream,
    private val segs: JitSegments
) : InputStream() {
    private var pos = 0L
    private val one = ByteArray(1)

    override fun read(): Int = if (read(one, 0, 1) <= 0) -1 else one[0].toInt() and 0xff

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        segs.prepare(pos)
        val n = base.read(b, off, len)
        if (n > 0) pos += n
        return n
    }

    override fun close() = base.close()
}

class ConcatStream(ctx: Context, items: List<VideoItem>) : VideoStream {
    private val pipe: String = FFmpegKitConfig.registerNewFFmpegPipe(ctx)
    private val list = File(ctx.cacheDir, "concat.txt")
    private val segs = JitSegments(ctx, items, File(ctx.cacheDir, "segs"))
    private val session: Session
    override val input: InputStream

    init {
        // سجل FFmpeg يتكتب في ملف السجل (يفيد كان صار crash)
        FFmpegKitConfig.enableLogCallback { log ->
            CrashLog.log(ctx, "ffmpeg: " + log.message.trim().take(300))
        }
        try {
            segs.prepare(0)
        } catch (e: Exception) {
            FFmpegKitConfig.closeFFmpegPipe(pipe)
            segs.cleanup()
            throw e
        }
        list.writeText(items.indices.joinToString("\n") { "file '${segs.path(it).absolutePath}'" })
        val cmd = "-y -f concat -safe 0 -i ${list.absolutePath} -c copy " +
            "-movflags frag_keyframe+empty_moov+default_base_moof -f mp4 $pipe"
        session = FFmpegKit.executeAsync(cmd) { }
        input = GatedInputStream(FileInputStream(pipe), segs)
    }

    /** آخر سطور من سجل FFmpeg (باش نعرفو علاش الدمج فشل) */
    override fun logs(): String = runCatching {
        session.getAllLogsAsString(5000).orEmpty().takeLast(700)
    }.getOrDefault("")

    override fun close() {
        runCatching { input.close() }
        runCatching { FFmpegKit.cancel(session.sessionId) }
        runCatching { FFmpegKitConfig.closeFFmpegPipe(pipe) }
        segs.cleanup()
    }
}

/** خطة الدمج: سريع (copy) كان الفيديوهات متوافقة، وإلا إعادة ترميز لدقة موحّدة */
data class MergePlan(val reencode: Boolean, val width: Int, val height: Int)

private data class MediaSig(
    val vMime: String, val w: Int, val h: Int,
    val aMime: String?, val sampleRate: Int, val channels: Int
)

fun planMerge(ctx: Context, items: List<VideoItem>): MergePlan {
    fun sig(item: VideoItem, idx: Int): MediaSig {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, item.videoUri, null)
            var vMime: String? = null
            var w = 0
            var h = 0
            var rot = 0
            var aMime: String? = null
            var sr = 0
            var ch = 0
            for (t in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(t)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && vMime == null) {
                    vMime = mime
                    w = f.getInteger(MediaFormat.KEY_WIDTH)
                    h = f.getInteger(MediaFormat.KEY_HEIGHT)
                    if (f.containsKey(MediaFormat.KEY_ROTATION)) rot = f.getInteger(MediaFormat.KEY_ROTATION)
                } else if (mime.startsWith("audio/") && aMime == null) {
                    aMime = mime
                    sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            if (vMime == null) {
                throw IllegalStateException("الفيديو رقم ${idx + 1} (${item.videoName}) ما فيهش صورة")
            }
            if (rot == 90 || rot == 270) { val tmp = w; w = h; h = tmp }
            return MediaSig(vMime, w, h, aMime, sr, ch)
        } finally {
            ex.release()
        }
    }

    val sigs = items.mapIndexed { i, it -> sig(it, i) }
    if (sigs.all { it == sigs[0] }) return MergePlan(false, sigs[0].w, sigs[0].h)

    // فيديوهات مختلفة: نوحّدوهم كلهم. لازم صوت في كل فيديو.
    sigs.forEachIndexed { i, sg ->
        if (sg.aMime == null) {
            throw IllegalStateException("الفيديو رقم ${i + 1} (${items[i].videoName}) ما فيهش صوت، ونحتاج صوت في كل الفيديوهات باش نوحّدهم")
        }
    }
    // ما نكبّروش أبداً: نختارو أصغر دقة (بالمساحة) ونصغّرو اللي أكبر منها
    // (مثلاً 1080p يولي 720p، و720p يبقى كما هو)
    val sizes = sigs.map { it.w to it.h }
    val target = sizes.minByOrNull { it.first.toLong() * it.second }!!
    return MergePlan(true, target.first - target.first % 2, target.second - target.second % 2)
}

fun hasEncoder(name: String): Boolean =
    runCatching { FFmpegKit.execute("-hide_banner -encoders").output.orEmpty().contains(" $name ") }
        .getOrDefault(false)

/**
 * إعادة ترميز: كل الفيديوهات تتوحّد (دقة، fps، صوت) وتتلصق في stream واحد.
 * أبطأ بكثير من الـ copy، لكن يخدم مع فيديوهات مختلفة.
 */
class ReencodeStream(ctx: Context, items: List<VideoItem>, plan: MergePlan) : VideoStream {
    private val pipe: String = FFmpegKitConfig.registerNewFFmpegPipe(ctx)
    private val session: Session
    override val input: InputStream
    val hardware: Boolean = hasEncoder("h264_mediacodec")

    init {
        val w = plan.width
        val h = plan.height
        val args = mutableListOf("-y")
        items.forEach { args += listOf("-i", FFmpegKitConfig.getSafParameterForRead(ctx, it.videoUri)) }

        val g = StringBuilder()
        items.indices.forEach { i ->
            g.append("[$i:v]scale=$w:$h:force_original_aspect_ratio=decrease,")
            g.append("pad=$w:$h:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,format=yuv420p[v$i];")
            g.append("[$i:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo[a$i];")
        }
        items.indices.forEach { g.append("[v$it][a$it]") }
        g.append("concat=n=${items.size}:v=1:a=1[v][a]")
        args += listOf("-filter_complex", g.toString(), "-map", "[v]", "-map", "[a]")

        val bitrate = if (h >= 1000) "6M" else if (h >= 700) "3500k" else "2M"
        args += if (hardware) listOf("-c:v", "h264_mediacodec", "-b:v", bitrate, "-g", "60")
        else listOf("-c:v", "mpeg4", "-b:v", bitrate, "-g", "60")
        args += listOf(
            "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
            "-movflags", "frag_keyframe+empty_moov+default_base_moof",
            "-f", "mp4", pipe
        )
        session = FFmpegKit.executeWithArgumentsAsync(args.toTypedArray()) { }
        input = FileInputStream(pipe)
    }

    override fun logs(): String = runCatching {
        session.getAllLogsAsString(5000).orEmpty().takeLast(700)
    }.getOrDefault("")

    override fun close() {
        runCatching { input.close() }
        runCatching { FFmpegKit.cancel(session.sessionId) }
        runCatching { FFmpegKitConfig.closeFFmpegPipe(pipe) }
    }
}

/* ============================================================
 *  5) الرفع لليوتيوب: Resumable Upload بـ chunks + captions
 * ============================================================ */
class YouTubeUploader(private val token: String) {

    private fun open(url: String, method: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.instanceFollowRedirects = false
        c.connectTimeout = 30_000
        c.readTimeout = 120_000
        c.setRequestProperty("Authorization", "Bearer $token")
        return c
    }

    /** يفتح جلسة رفع ويرجع الرابط متاعها */
    fun startSession(title: String): String {
        val c = open(
            "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
            "POST"
        )
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        c.setRequestProperty("X-Upload-Content-Type", "video/mp4")
        val body = JSONObject()
            .put("snippet", JSONObject().put("title", title).put("description", ""))
            .put("status", JSONObject().put("privacyStatus", "private"))
            .toString().toByteArray(Charsets.UTF_8)
        c.setFixedLengthStreamingMode(body.size)
        c.outputStream.use { it.write(body) }
        if (c.responseCode != 200) {
            throw IOException("startSession HTTP ${c.responseCode}: ${c.errorStream?.bufferedReader()?.readText()}")
        }
        return c.getHeaderField("Location") ?: throw IOException("ما فماش Location")
    }

    /** كم بايت وصلو للسيرفور */
    fun queryOffset(url: String): Long {
        val c = open(url, "PUT")
        c.doOutput = true
        c.setFixedLengthStreamingMode(0)
        c.setRequestProperty("Content-Range", "bytes */*")
        return when (c.responseCode) {
            308 -> {
                val range = c.getHeaderField("Range") // مثال: bytes=0-8388607
                if (range == null) 0L else range.substringAfter('-').toLong() + 1
            }
            200, 201 -> throw IllegalStateException("الرفع كمل ديجا")
            else -> throw IOException("queryOffset HTTP ${c.responseCode}")
        }
    }

    /** يبعث chunk. total = null كان مازال، والمجموع كان آخر chunk. يرجع videoId في الآخر */
    fun sendChunk(url: String, buf: ByteArray, off: Int, len: Int, start: Long, total: Long?): String? {
        val c = open(url, "PUT")
        c.doOutput = true
        c.setFixedLengthStreamingMode(len)
        c.setRequestProperty("Content-Type", "video/mp4")
        c.setRequestProperty("Content-Range", "bytes $start-${start + len - 1}/${total ?: "*"}")
        c.outputStream.use { it.write(buf, off, len) }
        return when (c.responseCode) {
            308 -> null
            200, 201 -> JSONObject(c.inputStream.bufferedReader().readText()).getString("id")
            else -> throw IOException("chunk HTTP ${c.responseCode}: ${c.errorStream?.bufferedReader()?.readText()}")
        }
    }

    /** يرفع ملف السوتيتراج الواحد (UTF-8) */
    fun uploadCaptions(videoId: String, srt: String) {
        val boundary = "ytmerge${System.currentTimeMillis()}"
        val meta = JSONObject().put(
            "snippet",
            JSONObject().put("videoId", videoId).put("language", "ar")
                .put("name", "العربية").put("isDraft", false)
        ).toString()
        val c = open(
            "https://www.googleapis.com/upload/youtube/v3/captions?uploadType=multipart&part=snippet",
            "POST"
        )
        c.doOutput = true
        c.setChunkedStreamingMode(0)
        c.setRequestProperty("Content-Type", "multipart/related; boundary=$boundary")
        c.outputStream.use { o ->
            o.write(
                ("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n" +
                    "--$boundary\r\nContent-Type: application/octet-stream\r\n\r\n")
                    .toByteArray(Charsets.UTF_8)
            )
            o.write(srt.toByteArray(Charsets.UTF_8))
            o.write("\r\n--$boundary--".toByteArray())
        }
        if (c.responseCode != 200) {
            throw IOException("captions HTTP ${c.responseCode}: ${c.errorStream?.bufferedReader()?.readText()}")
        }
    }
}

/* ============================================================
 *  6) الـ Worker: يجمع كل شي (يخدم في الخلفية مع notification)
 * ============================================================ */
class UploadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private val CHUNK = 8 * 1024 * 1024 // 32 × 256KB (شرط يوتيوب)
    private var fgError: String? = null
    private val STREAM_VER = "pipe-proc-v1"

    override suspend fun doWork(): Result {
        // نخلّيو المعالج والواي فاي يخدمو حتى كي الشاشة تتطفى
        val awake = KeepAwake.acquire(applicationContext)
        return try {
            run()
        } finally {
            awake.release()
        }
    }

    private suspend fun run(): Result = withContext(Dispatchers.IO) {
        val ctx = applicationContext
        try {
            // بقايا نسخ قديمة: ملفات دمج كبيرة تاكل المساحة
            File(ctx.filesDir, "merged_upload.mp4").delete()
            File(ctx.filesDir, "merged_upload.mp4.part").delete()
            File(ctx.filesDir, "merge_parts").deleteRecursively()
            status("تحضير الفيديوهات...")
            safeForeground("جاري التحضير...")
            val (title, items) = UploadJob.load(ctx)
            val plan = planMerge(ctx, items)
            UploadProgress.start(ctx, if (plan.reencode) emptyList() else items.map { fileSize(ctx, it.videoUri) })
            if (plan.reencode) {
                status("الفيديوهات مختلفة (دقة/كودك): نوحّدهم كلهم قبل الرفع (${plan.width}x${plan.height}). أبطأ ويسخّن التليفون، خلّيه في الشاحن.")
                delay(4000)
            }

            waitForAllowedNetwork()
            status("الاتصال بحساب يوتيوب...")
            val token = YouTubeAuth.accessToken(ctx)
                ?: return@withContext fail("لازم توافق على صلاحيات يوتيوب: دوس \"ارفع\" والابليكاسيون مفتوحة")
            status("تم الاتصال بيوتيوب ✓")
            val up = YouTubeUploader(token)
            val st = UploadJob.prefs(ctx)
            if (st.getString("stream_ver", null) != STREAM_VER) {
                // جلسة قديمة من طريقة دمج أخرى: ما نكمّلوش عليها (يتخرب الفيديو)
                st.edit().clear().putString("stream_ver", STREAM_VER).apply()
                status("نبدا رفع جديد من الصفر (طريقة الدمج تبدلت)...")
            }

            // أ) رفع الفيديو (مع استئناف كان صار انقطاع)
            var videoId = st.getString("videoId", null)
            if (videoId == null) {
                videoId = uploadVideo(up, title, items, plan)
                st.edit().putString("videoId", videoId).apply()
            }
            UploadProgress.done(ctx)

            // ب) السوتيتراج الواحد
            status("جاري رفع السوتيتراج...")
            safeForeground("جاري رفع السوتيتراج...")
            val srt = SrtMerger.mergeItems(ctx, items)
            up.uploadCaptions(videoId, srt)

            st.edit().clear().apply()
            UploadStatus.set(ctx, "تم الرفع ✓ https://youtu.be/$videoId (الفيديو private، شوفو في YouTube Studio)")
            notifyDone("تم الرفع ✓ (الفيديو private، شوفو في YouTube Studio)")
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e // الـ Worker توقّف (مثلاً النت تقطع)، WorkManager يعاود وحدو
        } catch (e: IllegalStateException) {
            fail(e.message ?: "خطأ")
        } catch (e: IOException) {
            UploadStatus.set(ctx, "مشكلة شبكة، نعاود المحاولة: ${e.message}")
            Result.retry() // يعاود وحدو ويكمل من وين وقف
        } catch (e: Exception) {
            fail("${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun status(text: String) {
        if (isStopped) return
        UploadStatus.set(applicationContext, text)
        runCatching {
            applicationContext.getSystemService(NotificationManager::class.java)
                .notify(1, buildNotification(text))
        }
    }

    /** إشعار عادي (يتنحّى بالسحب) كي يكمل الرفع ولا يفشل */
    private fun notifyDone(text: String) {
        runCatching {
            val ctx = applicationContext
            val open = PendingIntent.getActivity(
                ctx, 0,
                Intent(ctx, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE
            )
            val n = NotificationCompat.Builder(ctx, "upload")
                .setSmallIcon(android.R.drawable.stat_sys_upload_done)
                .setContentTitle("رفع إلى يوتيوب")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            ctx.getSystemService(NotificationManager::class.java).notify(2, n)
        }
    }

    /** كان "واي فاي فقط" مفعّل وما فماش واي فاي: نوقفو ونستنّاو (بلا ما نستهلكو الدوني) */
    private suspend fun waitForAllowedNetwork() {
        var waiting = false
        while (!UploadSettings.networkAllowed(applicationContext)) {
            if (!waiting) {
                waiting = true
                status("⏸ الرفع واقف: \"واي فاي فقط\" مفعّل وما فماش واي فاي. يكمل وحدو كي يرجع الواي فاي")
            }
            delay(3000)
        }
        if (waiting) status("رجع الاتصال المسموح، نكمل الرفع...")
    }

    private fun fail(text: String): Result {
        UploadStatus.set(applicationContext, "فشل: $text")
        notifyDone("فشل الرفع: $text")
        return Result.failure(workDataOf("error" to text))
    }

    /** الإشعار الدائم يحسّن الاستقرار، لكن كان ما يخدمش ما نوقفوش الرفع */
    private suspend fun safeForeground(text: String) {
        try {
            setForeground(foregroundInfo(text))
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            fgError = e.message ?: e.javaClass.simpleName
        }
    }

    private suspend fun uploadVideo(up: YouTubeUploader, title: String, items: List<VideoItem>, plan: MergePlan): String {
        val ctx = applicationContext
        val st = UploadJob.prefs(ctx)

        var url = st.getString("url", null)
        if (url != null && plan.reencode) {
            // إعادة الترميز ما تعاودش نفس البايتات، يعني نبدا من الصفر
            url = null
            st.edit().remove("url").apply()
        }
        var offset = 0L
        if (url == null) {
            url = up.startSession(title)
            st.edit().putString("url", url).apply()
        } else {
            status("نسأل يوتيوب وين وصل الرفع...")
            offset = up.queryOffset(url)
            status("يوتيوب استلم ${offset / (1024 * 1024)} MB. نشغّل الدمج ونكمل...")
        }
        UploadProgress.update(ctx, offset)

        status("تشغيل FFmpeg...")
        val sessionUrl: String = checkNotNull(url)
        val stream: VideoStream = if (plan.reencode) ReencodeStream(ctx, items, plan) else ConcatStream(ctx, items)
        if (stream is ReencodeStream) {
            status(if (stream.hardware) "إعادة الترميز بالهاردوير (أسرع)..." else "إعادة الترميز بالبرنامج (أبطأ)...")
        }
        stream.use { cs ->
            skipFully(cs.input, offset) // نعاودو نخرّجو الـ stream ونتخطّاو اللي وصل ديجا

            var prev = ByteArray(CHUNK)
            var next = ByteArray(CHUNK)
            var prevLen = readFully(cs.input, prev)
            if (prevLen == 0) throw IllegalStateException("الدمج ما خرّج بيانات. FFmpeg: ${cs.logs()}")
            var sent = offset

            while (true) {
                kotlinx.coroutines.currentCoroutineContext().ensureActive() // يوقف كي تدوس إيقاف/إلغاء
                val nextLen = readFully(cs.input, next)
                val isLast = nextLen == 0
                val id = sendReliable(up, sessionUrl, prev, prevLen, sent, if (isLast) sent + prevLen else null)
                sent += prevLen
                UploadProgress.update(ctx, sent)
                if ((sent / CHUNK) % 32L == 0L) CrashLog.log(ctx, "رفعنا ${sent / (1024 * 1024)} MB")
                val mb = sent / (1024 * 1024)
                safeForeground("تم رفع $mb MB")
                status(
                    "جاري الرفع: $mb MB" +
                        (fgError?.let { " ⚠ الإشعار الدائم ما خدمش ($it)، النظام ممكن يقتل الرفع" } ?: "")
                )
                if (isLast) return id ?: throw IOException("ما رجعش videoId")
                val t = prev; prev = next; next = t
                prevLen = nextLen
            }
        }
    }

    /** يبعث chunk، وكان صار انقطاع يستنى النت المسموح ويسأل السيرفور وين وصل */
    private suspend fun sendReliable(
        up: YouTubeUploader, url: String, buf: ByteArray, len: Int, start: Long, total: Long?
    ): String? {
        var off = 0
        var curStart = start
        var attempt = 0
        while (true) {
            waitForAllowedNetwork() // نوقفو كان "واي فاي فقط" مفعّل وما فماش واي فاي
            try {
                return up.sendChunk(url, buf, off, len - off, curStart, total)
            } catch (e: IOException) {
                if (++attempt > 8) throw e
                delay(5_000L * attempt)
                while (!UploadSettings.networkAllowed(applicationContext)) delay(5_000) // واي فاي فقط
                val srv = runCatching { up.queryOffset(url) }.getOrDefault(curStart)
                val consumed = (srv - start).toInt()
                if (total == null && consumed >= len) return null // السيرفور خذا الـ chunk كامل
                if (consumed in 1 until len) { off = consumed; curStart = srv }
            }
        }
    }

    private fun readFully(input: InputStream, buf: ByteArray): Int {
        var n = 0
        while (n < buf.size) {
            val r = input.read(buf, n, buf.size - n)
            if (r < 0) break
            n += r
        }
        return n
    }

    private fun skipFully(input: InputStream, n: Long) {
        var left = n
        var lastReport = 0L
        val tmp = ByteArray(1 shl 20)
        while (left > 0) {
            val r = input.read(tmp, 0, minOf(left, tmp.size.toLong()).toInt())
            if (r < 0) throw IOException("الـ stream أقصر من المتوقع")
            left -= r
            val done = n - left
            if (done - lastReport >= 128L * 1024 * 1024) {
                lastReport = done
                status("نتخطّى اللي رفعناه: ${done / (1024 * 1024)} / ${n / (1024 * 1024)} MB")
            }
        }
    }

    private fun buildNotification(text: String): Notification {
        val ctx = applicationContext
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("upload", "رفع الفيديو", NotificationManager.IMPORTANCE_LOW)
        )
        fun action(act: String, req: Int) = PendingIntent.getBroadcast(
            ctx, req, Intent(ctx, UploadControlReceiver::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(ctx, "upload")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("رفع إلى يوتيوب")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_media_pause, "⏸ إيقاف مؤقت", action("ytmerge.PAUSE", 1))
            .addAction(android.R.drawable.ic_delete, "⛔ إلغاء", action("ytmerge.CANCEL", 2))
            .build()
    }

    private fun foregroundInfo(text: String): ForegroundInfo {
        val n = buildNotification(text)
        return if (Build.VERSION.SDK_INT >= 29)
            ForegroundInfo(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(1, n)
    }
}


/** يمنع التليفون من النوم (CPU + واي فاي) وقت الرفع */
class KeepAwake private constructor(
    private val wake: PowerManager.WakeLock?,
    private val wifi: WifiManager.WifiLock?
) {
    fun release() {
        runCatching { wake?.let { if (it.isHeld) it.release() } }
        runCatching { wifi?.let { if (it.isHeld) it.release() } }
    }

    companion object {
        @Suppress("DEPRECATION")
        fun acquire(ctx: Context): KeepAwake {
            val wake = runCatching {
                ctx.getSystemService(PowerManager::class.java)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ytmerge:upload")
                    .apply { acquire(12 * 60 * 60 * 1000L) }
            }.getOrNull()
            val wifi = runCatching {
                ctx.applicationContext.getSystemService(WifiManager::class.java)
                    .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "ytmerge:wifi")
                    .apply { acquire() }
            }.getOrNull()
            return KeepAwake(wake, wifi)
        }
    }
}
