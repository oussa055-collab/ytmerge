package com.example.ytmerge

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.media.MediaMetadataRetriever
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.Session
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/* ============================================================
 *  1) الإعدادات: واي فاي فقط (par défaut) أو بالدوني
 * ============================================================ */
object UploadSettings {
    private fun p(ctx: Context) = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun wifiOnly(ctx: Context) = p(ctx).getBoolean("wifi_only", true)
    fun setWifiOnly(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("wifi_only", v).apply()

    fun networkAllowed(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        val needed = if (wifiOnly(ctx)) NetworkCapabilities.NET_CAPABILITY_NOT_METERED
        else NetworkCapabilities.NET_CAPABILITY_INTERNET
        return caps.hasCapability(needed)
    }
}

/** نص الحالة اللي يظهر في الابليكاسيون (باش تعرف شنو صاير) */
object UploadStatus {
    private fun p(ctx: Context) = ctx.getSharedPreferences("upload_status", Context.MODE_PRIVATE)
    fun set(ctx: Context, text: String) = p(ctx).edit().putString("text", text).apply()
    fun get(ctx: Context): String = p(ctx).getString("text", "") ?: ""
}

/* ============================================================
 *  2) تخزين المهمة (باش الـ Worker يعاود يبدا كان تسكّر الابليكاسيون)
 * ============================================================ */
object UploadJob {
    private fun file(ctx: Context) = File(ctx.filesDir, "job.json")
    private fun state(ctx: Context) = ctx.getSharedPreferences("upload_state", Context.MODE_PRIVATE)

    fun save(ctx: Context, title: String, items: List<VideoItem>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject()
                .put("v", it.videoUri.toString()).put("vn", it.videoName)
                .put("s", it.subUri.toString()).put("sn", it.subName))
        }
        file(ctx).writeText(JSONObject().put("title", title).put("items", arr).toString())
        state(ctx).edit().clear().apply() // مهمة جديدة ← نمسحو الحالة القديمة
    }

    fun load(ctx: Context): Pair<String, List<VideoItem>> {
        val o = JSONObject(file(ctx).readText())
        val arr = o.getJSONArray("items")
        val items = (0 until arr.length()).map {
            val j = arr.getJSONObject(it)
            VideoItem(Uri.parse(j.getString("v")), j.getString("vn"), Uri.parse(j.getString("s")), j.getString("sn"))
        }
        return o.getString("title") to items
    }

    fun prefs(ctx: Context) = state(ctx)
}

fun enqueueUpload(ctx: Context, title: String, items: List<VideoItem>) {
    UploadJob.save(ctx, title, items)
    UploadStatus.set(
        ctx,
        if (UploadSettings.wifiOnly(ctx)) "في الانتظار: الرفع يبدا كي تكون متصل بالواي فاي..."
        else "في الانتظار: الرفع باش يبدا..."
    )
    val constraints = Constraints.Builder()
        .setRequiredNetworkType(
            if (UploadSettings.wifiOnly(ctx)) NetworkType.UNMETERED else NetworkType.CONNECTED
        ).build()
    val req = OneTimeWorkRequestBuilder<UploadWorker>()
        .setConstraints(constraints)
        .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.SECONDS)
        .build()
    WorkManager.getInstance(ctx).enqueueUniqueWork("yt_upload", ExistingWorkPolicy.REPLACE, req)
}

/* ============================================================
 *  3) تسجيل الدخول (OAuth) والحصول على token
 *  لازم قبلها تعمل authorize مرة وحدة من الشاشة (UI) باش المستخدم يوافق.
 * ============================================================ */
object YouTubeAuth {
    private val SCOPES = listOf(
        Scope("https://www.googleapis.com/auth/youtube.upload"),
        Scope("https://www.googleapis.com/auth/youtube.force-ssl") // للـ captions
    )

    fun request(): AuthorizationRequest =
        AuthorizationRequest.builder().setRequestedScopes(SCOPES).build()

    /** يرجع null كان لازم المستخدم يوافق من الشاشة */
    suspend fun accessToken(ctx: Context): String? {
        val res = Identity.getAuthorizationClient(ctx).authorize(request()).await()
        return if (res.hasResolution()) null else res.accessToken
    }
}

/* ============================================================
 *  4) الدمج: FFmpeg يلصق الفيديوهات (بلا re-encoding) ويخرّجها في pipe
 *  صيغة fragmented MP4 باش تتقرا كـ stream من غير ملف كامل.
 * ============================================================ */
class ConcatStream(ctx: Context, items: List<VideoItem>) : AutoCloseable {
    private val pipe: String = FFmpegKitConfig.registerNewFFmpegPipe(ctx)
    private val list = File(ctx.cacheDir, "concat.txt")
    private val session: Session
    val input: InputStream

    init {
        list.writeText(items.joinToString("\n") {
            "file '${FFmpegKitConfig.getSafParameterForRead(ctx, it.videoUri)}'"
        })
        val cmd = "-y -f concat -safe 0 -protocol_whitelist file,saf,pipe " +
            "-i ${list.absolutePath} -c copy " +
            "-movflags frag_keyframe+empty_moov+default_base_moof -f mp4 $pipe"
        session = FFmpegKit.executeAsync(cmd) { }
        input = FileInputStream(pipe)
    }

    /** آخر سطور من سجل FFmpeg (باش نعرفو علاش الدمج فشل) */
    fun logs(): String = runCatching {
        session.getAllLogsAsString(5000).orEmpty().takeLast(700)
    }.getOrDefault("")

    override fun close() {
        runCatching { input.close() }
        runCatching { FFmpegKit.cancel(session.sessionId) }
        runCatching { FFmpegKitConfig.closeFFmpegPipe(pipe) }
    }
}

/** الدمج بلا re-encoding يخدم كان الفيديوهات نفس الدقة والاتجاه */
fun checkSameFormat(ctx: Context, items: List<VideoItem>) {
    fun info(uri: Uri): String {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            fun k(key: Int) = r.extractMetadata(key)
            "${k(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)}x" +
                "${k(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)}" +
                " rot${k(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)}"
        } finally {
            r.release()
        }
    }
    val first = info(items.first().videoUri)
    items.forEachIndexed { i, it ->
        val x = info(it.videoUri)
        if (x != first) {
            throw IllegalStateException("الفيديو رقم ${i + 1} (${it.videoName}) مختلف: $x بدل $first")
        }
    }
}

/* ============================================================
 *  5) الرفع لليوتيوب: Resumable Upload بـ chunks + captions
 * ============================================================ */
class YouTubeUploader(private val token: String) {

    private fun open(url: String, method: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.instanceFollowRedirects = false
        c.connectTimeout = 30_000
        c.readTimeout = 120_000
        c.setRequestProperty("Authorization", "Bearer $token")
        return c
    }

    /** يفتح جلسة رفع ويرجع الرابط متاعها */
    fun startSession(title: String): String {
        val c = open(
            "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
            "POST"
        )
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        c.setRequestProperty("X-Upload-Content-Type", "video/mp4")
        val body = JSONObject()
            .put("snippet", JSONObject().put("title", title).put("description", ""))
            .put("status", JSONObject().put("privacyStatus", "private"))
            .toString().toByteArray(Charsets.UTF_8)
        c.setFixedLengthStreamingMode(body.size)
        c.outputStream.use { it.write(body) }
        if (c.responseCode != 200) {
            throw IOException("startSession HTTP ${c.responseCode}: ${c.errorStream?.bufferedReader()?.readText()}")
        }
        return c.getHeaderField("Location") ?: throw IOException("ما فماش Location")
    }

    /** كم بايت وصلو للسيرفور */
    fun queryOffset(url: String): Long {
        val c = open(url, "PUT")
        c.doOutput = true
        c.setFixedLengthStreamingMode(0)
        c.setRequestProperty("Content-Range", "bytes */*")
        return when (c.responseCode) {
            308 -> {
                val range = c.getHeaderField("Range") // مثال: bytes=0-8388607
                if (range == null) 0L else range.substringAfter('-').toLong() + 1
            }
            200, 201 -> throw IllegalStateException("الرفع كمل ديجا")
            else -> throw IOException("queryOffset HTTP ${c.responseCode}")
        }
    }

    /** يبعث chunk. total = null كان مازال، والمجموع كان آخر chunk. يرجع videoId في الآخر */
    fun sendChunk(url: String, buf: ByteArray, off: Int, len: Int, start: Long, total: Long?): String? {
        val c = open(url, "PUT")
        c.doOutput = true
        c.setFixedLengthStreamingMode(len)
        c.setRequestProperty("Content-Type", "video/mp4")
        c.setRequestProperty("Content-Range", "bytes $start-${start + len - 1}/${total ?: "*"}")
        c.outputStream.use { it.write(buf, off, len) }
        return when (c.responseCode) {
            308 -> null
            200, 201 -> JSONObject(c.inputStream.bufferedReader().readText()).getString("id")
            else -> throw IOException("chunk HTTP ${c.responseCode}: ${c.errorStream?.bufferedReader()?.readText()}")
        }
    }

    /** يرفع ملف السوتيتراج الواحد (UTF-8) */
    fun uploadCaptions(videoId: String, srt: String) {
        val boundary = "ytmerge${System.currentTimeMillis()}"
        val meta = JSONObject().put(
            "snippet",
            JSONObject().put("videoId", videoId).put("language", "ar")
                .put("name", "العربية").put("isDraft", false)
        ).toString()
        val c = open(
            "https://www.googleapis.com/upload/youtube/v3/captions?uploadType=multipart&part=snippet",
            "POST"
        )
        c.doOutput = true
        c.setChunkedStreamingMode(0)
        c.setRequestProperty("Content-Type", "multipart/related; boundary=$boundary")
        c.outputStream.use { o ->
            o.write(
                ("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n" +
                    "--$boundary\r\nContent-Type: application/octet-stream\r\n\r\n")
                    .toByteArray(Charsets.UTF_8)
            )
            o.write(srt.toByteArray(Charsets.UTF_8))
            o.write("\r\n--$boundary--".toByteArray())
        }
        if (c.responseCode != 200) {
            throw IOException("captions HTTP ${c.responseCode}: ${c.errorStream?.bufferedReader()?.readText()}")
        }
    }
}

/* ============================================================
 *  6) الـ Worker: يجمع كل شي (يخدم في الخلفية مع notification)
 * ============================================================ */
class UploadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private val CHUNK = 8 * 1024 * 1024 // 32 × 256KB (شرط يوتيوب)

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val ctx = applicationContext
        try {
            status("تحضير الفيديوهات...")
            safeForeground("جاري التحضير...")
            val (title, items) = UploadJob.load(ctx)
            checkSameFormat(ctx, items)

            status("الاتصال بحساب يوتيوب...")
            val token = YouTubeAuth.accessToken(ctx)
                ?: return@withContext fail("لازم توافق على صلاحيات يوتيوب: دوس \"ارفع\" والابليكاسيون مفتوحة")
            val up = YouTubeUploader(token)
            val st = UploadJob.prefs(ctx)

            // أ) رفع الفيديو (مع استئناف كان صار انقطاع)
            var videoId = st.getString("videoId", null)
            if (videoId == null) {
                videoId = uploadVideo(up, title, items)
                st.edit().putString("videoId", videoId).apply()
            }

            // ب) السوتيتراج الواحد
            status("جاري رفع السوتيتراج...")
            safeForeground("جاري رفع السوتيتراج...")
            val srt = SrtMerger.mergeItems(ctx, items)
            up.uploadCaptions(videoId, srt)

            st.edit().clear().apply()
            status("تم الرفع ✓ https://youtu.be/$videoId (الفيديو private، شوفو في YouTube Studio)")
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e // الـ Worker توقّف (مثلاً النت تقطع)، WorkManager يعاود وحدو
        } catch (e: IllegalStateException) {
            fail(e.message ?: "خطأ")
        } catch (e: IOException) {
            status("مشكلة شبكة، نعاود المحاولة: ${e.message}")
            Result.retry() // يعاود وحدو ويكمل من وين وقف
        } catch (e: Exception) {
            fail("${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun status(text: String) = UploadStatus.set(applicationContext, text)

    private fun fail(text: String): Result {
        status("فشل: $text")
        return Result.failure(workDataOf("error" to text))
    }

    /** الإشعار الدائم يحسّن الاستقرار، لكن كان ما يخدمش ما نوقفوش الرفع */
    private suspend fun safeForeground(text: String) {
        runCatching { setForeground(foregroundInfo(text)) }
    }

    private suspend fun uploadVideo(up: YouTubeUploader, title: String, items: List<VideoItem>): String {
        val ctx = applicationContext
        val st = UploadJob.prefs(ctx)

        var url = st.getString("url", null)
        var offset = 0L
        if (url == null) {
            url = up.startSession(title)
            st.edit().putString("url", url).apply()
        } else {
            offset = up.queryOffset(url)
        }

        ConcatStream(ctx, items).use { cs ->
            skipFully(cs.input, offset) // نعاودو نخرّجو الـ stream ونتخطّاو اللي وصل ديجا

            var prev = ByteArray(CHUNK)
            var next = ByteArray(CHUNK)
            var prevLen = readFully(cs.input, prev)
            if (prevLen == 0) throw IllegalStateException("الدمج ما خرّج بيانات. FFmpeg: ${cs.logs()}")
            var sent = offset

            while (true) {
                val nextLen = readFully(cs.input, next)
                val isLast = nextLen == 0
                val id = sendReliable(up, url, prev, prevLen, sent, if (isLast) sent + prevLen else null)
                sent += prevLen
                val mb = sent / (1024 * 1024)
                status("جاري الرفع: $mb MB")
                safeForeground("تم رفع $mb MB")
                if (isLast) return id ?: throw IOException("ما رجعش videoId")
                val t = prev; prev = next; next = t
                prevLen = nextLen
            }
        }
    }

    /** يبعث chunk، وكان صار انقطاع يستنى النت المسموح ويسأل السيرفور وين وصل */
    private suspend fun sendReliable(
        up: YouTubeUploader, url: String, buf: ByteArray, len: Int, start: Long, total: Long?
    ): String? {
        var off = 0
        var curStart = start
        var attempt = 0
        while (true) {
            try {
                return up.sendChunk(url, buf, off, len - off, curStart, total)
            } catch (e: IOException) {
                if (++attempt > 8) throw e
                delay(5_000L * attempt)
                while (!UploadSettings.networkAllowed(applicationContext)) delay(5_000) // واي فاي فقط
                val srv = runCatching { up.queryOffset(url) }.getOrDefault(curStart)
                val consumed = (srv - start).toInt()
                if (total == null && consumed >= len) return null // السيرفور خذا الـ chunk كامل
                if (consumed in 1 until len) { off = consumed; curStart = srv }
            }
        }
    }

    private fun readFully(input: InputStream, buf: ByteArray): Int {
        var n = 0
        while (n < buf.size) {
            val r = input.read(buf, n, buf.size - n)
            if (r < 0) break
            n += r
        }
        return n
    }

    private fun skipFully(input: InputStream, n: Long) {
        var left = n
        val tmp = ByteArray(1 shl 20)
        while (left > 0) {
            val r = input.read(tmp, 0, minOf(left, tmp.size.toLong()).toInt())
            if (r < 0) throw IOException("الـ stream أقصر من المتوقع")
            left -= r
        }
    }

    private fun foregroundInfo(text: String): ForegroundInfo {
        val ctx = applicationContext
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("upload", "رفع الفيديو", NotificationManager.IMPORTANCE_LOW)
        )
        val n = NotificationCompat.Builder(ctx, "upload")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("رفع إلى يوتيوب")
            .setContentText(text)
            .setOngoing(true)
            .build()
        return if (Build.VERSION.SDK_INT >= 29)
            ForegroundInfo(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(1, n)
    }
}
