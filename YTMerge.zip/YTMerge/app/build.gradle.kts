plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.ytmerge"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.ytmerge"
        minSdk = 26
        targetSdk = 34
        // versionCode يزيد وحدو مع كل build (بالدقائق)، باش التحديث ما يعطيش خطأ تعارض
        versionCode = (System.currentTimeMillis() / 60000).toInt()
        versionName = "1.0"
        // مكتبة FFmpeg المتوفرة arm64 فقط (تليفونك Redmi Note 14 arm64)
        ndk { abiFilters += "arm64-v8a" }
    }

    signingConfigs {
        // keystore ثابت، باش الـ SHA-1 ما يتبدلش مع كل build في GitHub
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildFeatures { compose = true }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")

    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")

    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")

    // FFmpegKit (fork متواصل، نفس الـ package: com.arthenica.ffmpegkit)
    implementation("dev.ffmpegkit-maintained:ffmpeg:7.1.6")
}
